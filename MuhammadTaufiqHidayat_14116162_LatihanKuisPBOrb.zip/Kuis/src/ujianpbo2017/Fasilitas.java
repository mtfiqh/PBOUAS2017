/*
 * Fasilitas Terdiri dari: USG, Ruang Rawat Inap, Cek Darah, CT Scan
 */
package ujianpbo2017;

/**
 *
 * @author ahmadluky
 */
public abstract class Fasilitas {
    String satuan;
    public abstract double hitungTagihan();
}
